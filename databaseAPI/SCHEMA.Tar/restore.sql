--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "LimReview";
--
-- Name: LimReview; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "LimReview" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "LimReview" OWNER TO postgres;

\connect "LimReview"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: get_product_lowest_price(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_product_lowest_price(product_uuid uuid) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE
    lowest_price NUMERIC(10,2);
BEGIN
    SELECT MIN(price) INTO lowest_price
    FROM store_links 
    WHERE product_id = product_uuid AND price > 0;
    
    IF lowest_price IS NULL THEN
        SELECT price INTO lowest_price
        FROM products
        WHERE id = product_uuid;
    END IF;
    
    RETURN COALESCE(lowest_price, 0);
END;
$$;


ALTER FUNCTION public.get_product_lowest_price(product_uuid uuid) OWNER TO postgres;

--
-- Name: FUNCTION get_product_lowest_price(product_uuid uuid); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.get_product_lowest_price(product_uuid uuid) IS 'Get the lowest price for a product from store_links, fallback to product.price';


--
-- Name: update_product_price(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_product_price() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Update product price to lowest store_links price for the affected product
    UPDATE products 
    SET price = (
        SELECT MIN(price) 
        FROM store_links 
        WHERE product_id = COALESCE(NEW.product_id, OLD.product_id)
        AND price IS NOT NULL
    )
    WHERE id = COALESCE(NEW.product_id, OLD.product_id);
    
    RETURN COALESCE(NEW, OLD);
END;
$$;


ALTER FUNCTION public.update_product_price() OWNER TO postgres;

--
-- Name: update_product_rating(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_product_rating() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
        UPDATE products 
        SET 
            average_rating = (
                SELECT COALESCE(AVG(rating::DECIMAL), 0) 
                FROM reviews 
                WHERE product_id = NEW.product_id AND status = 'published'
            ),
            review_count = (
                SELECT COUNT(*) 
                FROM reviews 
                WHERE product_id = NEW.product_id AND status = 'published'
            )
        WHERE id = NEW.product_id;
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE products 
        SET 
            average_rating = (
                SELECT COALESCE(AVG(rating::DECIMAL), 0) 
                FROM reviews 
                WHERE product_id = OLD.product_id AND status = 'published'
            ),
            review_count = (
                SELECT COUNT(*) 
                FROM reviews 
                WHERE product_id = OLD.product_id AND status = 'published'
            )
        WHERE id = OLD.product_id;
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.update_product_rating() OWNER TO postgres;

--
-- Name: update_review_helpful_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_review_helpful_count() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE reviews 
        SET helpful_count = helpful_count + 1
        WHERE id = NEW.review_id;
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE reviews 
        SET helpful_count = helpful_count - 1
        WHERE id = OLD.review_id;
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.update_review_helpful_count() OWNER TO postgres;

--
-- Name: validate_password_strength(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.validate_password_strength(password_text text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check minimum length (8 characters)
    IF LENGTH(password_text) < 8 THEN
        RETURN FALSE;
    END IF;
    
    -- Check for at least one uppercase letter
    IF password_text !~ '[A-Z]' THEN
        RETURN FALSE;
    END IF;
    
    -- Check for at least one lowercase letter  
    IF password_text !~ '[a-z]' THEN
        RETURN FALSE;
    END IF;
    
    -- Check for at least one digit
    IF password_text !~ '[0-9]' THEN
        RETURN FALSE;
    END IF;
    
    -- Check for at least one special character
    IF password_text !~ '[^A-Za-z0-9]' THEN
        RETURN FALSE;
    END IF;
    
    RETURN TRUE;
END;
$$;


ALTER FUNCTION public.validate_password_strength(password_text text) OWNER TO postgres;

--
-- Name: FUNCTION validate_password_strength(password_text text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.validate_password_strength(password_text text) IS 'Validates password strength: min 8 chars, 1 uppercase, 1 lowercase, 1 number, 1 special character';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: contact_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact_messages (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    message text NOT NULL,
    status character varying(20) DEFAULT 'unread'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT contact_messages_status_check CHECK (((status)::text = ANY ((ARRAY['unread'::character varying, 'read'::character varying, 'replied'::character varying])::text[])))
);


ALTER TABLE public.contact_messages OWNER TO postgres;

--
-- Name: product_features; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_features (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    product_id uuid,
    feature_text character varying(500) NOT NULL,
    sort_order integer DEFAULT 0
);


ALTER TABLE public.product_features OWNER TO postgres;

--
-- Name: product_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_images (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    product_id uuid,
    image_url character varying(500) NOT NULL,
    is_primary boolean DEFAULT false,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.product_images OWNER TO postgres;

--
-- Name: product_specifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_specifications (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    product_id uuid,
    spec_name character varying(100) NOT NULL,
    spec_value character varying(500) NOT NULL
);


ALTER TABLE public.product_specifications OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    category_id uuid,
    manufacturer character varying(255),
    price numeric(10,2),
    product_url character varying(500),
    availability character varying(100),
    average_rating numeric(3,2) DEFAULT 0.0,
    review_count integer DEFAULT 0,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT products_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'pending'::character varying])::text[])))
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: COLUMN products.price; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.products.price IS 'Current price - automatically updated to the lowest price from store_links';


--
-- Name: products_with_image; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.products_with_image AS
 SELECT p.id,
    p.name,
    p.description,
    p.category_id,
    p.manufacturer,
    p.price,
    p.product_url,
    p.availability,
    p.average_rating,
    p.review_count,
    p.status,
    p.created_at,
    p.updated_at,
    pi.image_url AS first_image_url,
    pi.is_primary,
        CASE
            WHEN (pi.image_url IS NOT NULL) THEN pi.image_url
            ELSE NULL::character varying
        END AS display_image
   FROM (public.products p
     LEFT JOIN ( SELECT DISTINCT ON (product_images.product_id) product_images.product_id,
            product_images.image_url,
            product_images.is_primary,
            product_images.created_at
           FROM public.product_images
          ORDER BY product_images.product_id, product_images.is_primary DESC, product_images.created_at) pi ON ((p.id = pi.product_id)));


ALTER VIEW public.products_with_image OWNER TO postgres;

--
-- Name: VIEW products_with_image; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON VIEW public.products_with_image IS 'Products with their first/primary image from product_images table. Use display_image for frontend display.';


--
-- Name: store_links; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_links (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    product_id uuid,
    store_name character varying(100) NOT NULL,
    price numeric(10,2),
    url character varying(500) NOT NULL,
    is_official boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.store_links OWNER TO postgres;

--
-- Name: products_with_pricing; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.products_with_pricing AS
 SELECT id,
    name,
    description,
    category_id,
    manufacturer,
    price,
    product_url,
    availability,
    average_rating,
    review_count,
    status,
    created_at,
    updated_at,
    public.get_product_lowest_price(id) AS lowest_price,
    ( SELECT count(*) AS count
           FROM public.store_links sl
          WHERE (sl.product_id = p.id)) AS store_count
   FROM public.products p;


ALTER VIEW public.products_with_pricing OWNER TO postgres;

--
-- Name: VIEW products_with_pricing; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON VIEW public.products_with_pricing IS 'Products with calculated lowest price from store_links';


--
-- Name: review_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review_comments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    review_id uuid NOT NULL,
    user_id uuid NOT NULL,
    parent_id uuid,
    content text NOT NULL,
    status character varying(20) DEFAULT 'visible'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT review_comments_status_check CHECK (((status)::text = ANY ((ARRAY['visible'::character varying, 'hidden'::character varying, 'deleted'::character varying])::text[])))
);


ALTER TABLE public.review_comments OWNER TO postgres;

--
-- Name: review_cons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review_cons (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    review_id uuid,
    con_text character varying(500) NOT NULL,
    sort_order integer DEFAULT 0
);


ALTER TABLE public.review_cons OWNER TO postgres;

--
-- Name: review_helpful_votes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review_helpful_votes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    review_id uuid,
    user_id uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.review_helpful_votes OWNER TO postgres;

--
-- Name: review_media; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review_media (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    review_id uuid,
    media_url character varying(500) NOT NULL,
    media_type character varying(20),
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT review_media_media_type_check CHECK (((media_type)::text = ANY ((ARRAY['image'::character varying, 'video'::character varying])::text[])))
);


ALTER TABLE public.review_media OWNER TO postgres;

--
-- Name: review_pros; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review_pros (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    review_id uuid,
    pro_text character varying(500) NOT NULL,
    sort_order integer DEFAULT 0
);


ALTER TABLE public.review_pros OWNER TO postgres;

--
-- Name: review_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review_requests (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    product_name character varying(255) NOT NULL,
    manufacturer character varying(255),
    category_id uuid,
    product_url character varying(500),
    price numeric(10,2),
    availability character varying(100),
    description text,
    reasoning text,
    contact_email character varying(255),
    status character varying(20) DEFAULT 'pending'::character varying,
    admin_notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT review_requests_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying, 'completed'::character varying])::text[])))
);


ALTER TABLE public.review_requests OWNER TO postgres;

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reviews (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    product_id uuid,
    rating integer,
    title character varying(255),
    content text,
    status character varying(20) DEFAULT 'pending'::character varying,
    helpful_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT reviews_rating_check CHECK (((rating >= 1) AND (rating <= 5))),
    CONSTRAINT reviews_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'published'::character varying, 'rejected'::character varying])::text[])))
);


ALTER TABLE public.reviews OWNER TO postgres;

--
-- Name: user_follows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_follows (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    follower_id uuid,
    followed_id uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_follows OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    avatar character varying(500),
    role character varying(20) DEFAULT 'user'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    email_verified boolean DEFAULT false,
    verification_token character varying(255),
    verification_token_expires timestamp without time zone,
    verification_sent_at timestamp without time zone,
    CONSTRAINT password_hash_not_empty CHECK ((length((password_hash)::text) > 0)),
    CONSTRAINT users_role_check CHECK (((role)::text = ANY (ARRAY['user'::text, 'admin'::text, 'reviewer'::text])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: COLUMN users.password_hash; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.password_hash IS 'Hashed password. Original password must meet requirements: min 8 chars, 1 uppercase, 1 lowercase, 1 number, 1 special character';


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, slug, description, created_at) FROM stdin;
\.
COPY public.categories (id, name, slug, description, created_at) FROM '$$PATH$$/5069.dat';

--
-- Data for Name: contact_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact_messages (id, name, email, subject, message, status, created_at) FROM stdin;
\.
COPY public.contact_messages (id, name, email, subject, message, status, created_at) FROM '$$PATH$$/5081.dat';

--
-- Data for Name: product_features; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_features (id, product_id, feature_text, sort_order) FROM stdin;
\.
COPY public.product_features (id, product_id, feature_text, sort_order) FROM '$$PATH$$/5072.dat';

--
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_images (id, product_id, image_url, is_primary, sort_order, created_at) FROM stdin;
\.
COPY public.product_images (id, product_id, image_url, is_primary, sort_order, created_at) FROM '$$PATH$$/5071.dat';

--
-- Data for Name: product_specifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_specifications (id, product_id, spec_name, spec_value) FROM stdin;
\.
COPY public.product_specifications (id, product_id, spec_name, spec_value) FROM '$$PATH$$/5073.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, name, description, category_id, manufacturer, price, product_url, availability, average_rating, review_count, status, created_at, updated_at) FROM stdin;
\.
COPY public.products (id, name, description, category_id, manufacturer, price, product_url, availability, average_rating, review_count, status, created_at, updated_at) FROM '$$PATH$$/5070.dat';

--
-- Data for Name: review_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.review_comments (id, review_id, user_id, parent_id, content, status, created_at, updated_at) FROM stdin;
\.
COPY public.review_comments (id, review_id, user_id, parent_id, content, status, created_at, updated_at) FROM '$$PATH$$/5083.dat';

--
-- Data for Name: review_cons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.review_cons (id, review_id, con_text, sort_order) FROM stdin;
\.
COPY public.review_cons (id, review_id, con_text, sort_order) FROM '$$PATH$$/5077.dat';

--
-- Data for Name: review_helpful_votes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.review_helpful_votes (id, review_id, user_id, created_at) FROM stdin;
\.
COPY public.review_helpful_votes (id, review_id, user_id, created_at) FROM '$$PATH$$/5079.dat';

--
-- Data for Name: review_media; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.review_media (id, review_id, media_url, media_type, sort_order, created_at) FROM stdin;
\.
COPY public.review_media (id, review_id, media_url, media_type, sort_order, created_at) FROM '$$PATH$$/5078.dat';

--
-- Data for Name: review_pros; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.review_pros (id, review_id, pro_text, sort_order) FROM stdin;
\.
COPY public.review_pros (id, review_id, pro_text, sort_order) FROM '$$PATH$$/5076.dat';

--
-- Data for Name: review_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.review_requests (id, user_id, product_name, manufacturer, category_id, product_url, price, availability, description, reasoning, contact_email, status, admin_notes, created_at, updated_at) FROM stdin;
\.
COPY public.review_requests (id, user_id, product_name, manufacturer, category_id, product_url, price, availability, description, reasoning, contact_email, status, admin_notes, created_at, updated_at) FROM '$$PATH$$/5080.dat';

--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reviews (id, user_id, product_id, rating, title, content, status, helpful_count, created_at, updated_at) FROM stdin;
\.
COPY public.reviews (id, user_id, product_id, rating, title, content, status, helpful_count, created_at, updated_at) FROM '$$PATH$$/5075.dat';

--
-- Data for Name: store_links; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_links (id, product_id, store_name, price, url, is_official, created_at) FROM stdin;
\.
COPY public.store_links (id, product_id, store_name, price, url, is_official, created_at) FROM '$$PATH$$/5074.dat';

--
-- Data for Name: user_follows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_follows (id, follower_id, followed_id, created_at) FROM stdin;
\.
COPY public.user_follows (id, follower_id, followed_id, created_at) FROM '$$PATH$$/5082.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, name, password_hash, avatar, role, created_at, updated_at, email_verified, verification_token, verification_token_expires, verification_sent_at) FROM stdin;
\.
COPY public.users (id, email, name, password_hash, avatar, role, created_at, updated_at, email_verified, verification_token, verification_token_expires, verification_sent_at) FROM '$$PATH$$/5068.dat';

--
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_name_key UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: categories categories_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_slug_key UNIQUE (slug);


--
-- Name: contact_messages contact_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_messages
    ADD CONSTRAINT contact_messages_pkey PRIMARY KEY (id);


--
-- Name: product_features product_features_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_features
    ADD CONSTRAINT product_features_pkey PRIMARY KEY (id);


--
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- Name: product_specifications product_specifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_specifications
    ADD CONSTRAINT product_specifications_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: review_comments review_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_comments
    ADD CONSTRAINT review_comments_pkey PRIMARY KEY (id);


--
-- Name: review_cons review_cons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_cons
    ADD CONSTRAINT review_cons_pkey PRIMARY KEY (id);


--
-- Name: review_helpful_votes review_helpful_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_helpful_votes
    ADD CONSTRAINT review_helpful_votes_pkey PRIMARY KEY (id);


--
-- Name: review_helpful_votes review_helpful_votes_review_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_helpful_votes
    ADD CONSTRAINT review_helpful_votes_review_id_user_id_key UNIQUE (review_id, user_id);


--
-- Name: review_media review_media_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_media
    ADD CONSTRAINT review_media_pkey PRIMARY KEY (id);


--
-- Name: review_pros review_pros_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_pros
    ADD CONSTRAINT review_pros_pkey PRIMARY KEY (id);


--
-- Name: review_requests review_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_requests
    ADD CONSTRAINT review_requests_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_user_id_product_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_user_id_product_id_key UNIQUE (user_id, product_id);


--
-- Name: store_links store_links_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_links
    ADD CONSTRAINT store_links_pkey PRIMARY KEY (id);


--
-- Name: user_follows user_follows_follower_id_followed_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_follows
    ADD CONSTRAINT user_follows_follower_id_followed_id_key UNIQUE (follower_id, followed_id);


--
-- Name: user_follows user_follows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_follows
    ADD CONSTRAINT user_follows_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_product_images_product; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_images_product ON public.product_images USING btree (product_id);


--
-- Name: idx_products_avg_rating; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_avg_rating ON public.products USING btree (average_rating DESC);


--
-- Name: idx_products_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_category ON public.products USING btree (category_id);


--
-- Name: idx_products_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_created_at ON public.products USING btree (created_at DESC);


--
-- Name: idx_products_review_count; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_review_count ON public.products USING btree (review_count DESC);


--
-- Name: idx_review_comments_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_review_comments_created ON public.review_comments USING btree (created_at DESC);


--
-- Name: idx_review_comments_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_review_comments_parent ON public.review_comments USING btree (parent_id);


--
-- Name: idx_review_comments_review; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_review_comments_review ON public.review_comments USING btree (review_id);


--
-- Name: idx_review_helpful_votes_review; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_review_helpful_votes_review ON public.review_helpful_votes USING btree (review_id);


--
-- Name: idx_reviews_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reviews_created_at ON public.reviews USING btree (created_at DESC);


--
-- Name: idx_reviews_product; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reviews_product ON public.reviews USING btree (product_id);


--
-- Name: idx_reviews_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reviews_status ON public.reviews USING btree (status);


--
-- Name: idx_reviews_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reviews_user ON public.reviews USING btree (user_id);


--
-- Name: idx_store_links_price; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_store_links_price ON public.store_links USING btree (product_id, price) WHERE (price IS NOT NULL);


--
-- Name: idx_users_verification_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_verification_token ON public.users USING btree (verification_token);


--
-- Name: uniq_store_links_product_url; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uniq_store_links_product_url ON public.store_links USING btree (product_id, url);


--
-- Name: store_links trigger_update_product_price; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_product_price AFTER INSERT OR DELETE OR UPDATE ON public.store_links FOR EACH ROW EXECUTE FUNCTION public.update_product_price();


--
-- Name: reviews trigger_update_product_rating; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_product_rating AFTER INSERT OR DELETE OR UPDATE ON public.reviews FOR EACH ROW EXECUTE FUNCTION public.update_product_rating();


--
-- Name: review_helpful_votes trigger_update_review_helpful_count; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_review_helpful_count AFTER INSERT OR DELETE ON public.review_helpful_votes FOR EACH ROW EXECUTE FUNCTION public.update_review_helpful_count();


--
-- Name: product_features product_features_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_features
    ADD CONSTRAINT product_features_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_images product_images_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_specifications product_specifications_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_specifications
    ADD CONSTRAINT product_specifications_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: review_comments review_comments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_comments
    ADD CONSTRAINT review_comments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.review_comments(id) ON DELETE CASCADE;


--
-- Name: review_comments review_comments_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_comments
    ADD CONSTRAINT review_comments_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.reviews(id) ON DELETE CASCADE;


--
-- Name: review_comments review_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_comments
    ADD CONSTRAINT review_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: review_cons review_cons_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_cons
    ADD CONSTRAINT review_cons_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.reviews(id) ON DELETE CASCADE;


--
-- Name: review_helpful_votes review_helpful_votes_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_helpful_votes
    ADD CONSTRAINT review_helpful_votes_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.reviews(id) ON DELETE CASCADE;


--
-- Name: review_helpful_votes review_helpful_votes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_helpful_votes
    ADD CONSTRAINT review_helpful_votes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: review_media review_media_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_media
    ADD CONSTRAINT review_media_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.reviews(id) ON DELETE CASCADE;


--
-- Name: review_pros review_pros_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_pros
    ADD CONSTRAINT review_pros_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.reviews(id) ON DELETE CASCADE;


--
-- Name: review_requests review_requests_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_requests
    ADD CONSTRAINT review_requests_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: review_requests review_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_requests
    ADD CONSTRAINT review_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: store_links store_links_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_links
    ADD CONSTRAINT store_links_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: user_follows user_follows_followed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_follows
    ADD CONSTRAINT user_follows_followed_id_fkey FOREIGN KEY (followed_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_follows user_follows_follower_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_follows
    ADD CONSTRAINT user_follows_follower_id_fkey FOREIGN KEY (follower_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: DATABASE "LimReview"; Type: ACL; Schema: -; Owner: postgres
--

GRANT TEMPORARY ON DATABASE "LimReview" TO tauri_app_user;


--
-- PostgreSQL database dump complete
--

